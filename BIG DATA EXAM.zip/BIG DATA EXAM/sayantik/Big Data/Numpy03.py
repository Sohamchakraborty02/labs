# Q8. Write a python program to
#  Create an identity matrix of dimension 4-by-4
#  Element-wise addition of 2 numpy arrays
#  Transpose 1 st matrix using numpy
#  Multiply transpose matrix to 2 nd Matrix.

import numpy as np

def input_matrix(name):
    print(f"Enter the elements of {name} (4x4 matrix):")
    matrix = []
    for i in range(4):
        row = input().split()
        matrix.append([int(x) for x in row])
    return np.array(matrix)

matrix1 = input_matrix("Matrix 1")
matrix2 = input_matrix("Matrix 2")

identity_matrix = np.eye(4)
print("\nIdentity Matrix (4x4):")
print(identity_matrix)

added_matrix = np.add(matrix1, matrix2)
print("\nElement-wise Addition of Matrix 1 and Matrix 2:")
print(added_matrix)

transposed_matrix1 = np.transpose(matrix1)
print("\nTranspose of Matrix 1:")
print(transposed_matrix1)

result_matrix = np.dot(transposed_matrix1, matrix2)
print("\nMatrix multiplication of Transpose of Matrix 1 and Matrix 2:")
print(result_matrix)

