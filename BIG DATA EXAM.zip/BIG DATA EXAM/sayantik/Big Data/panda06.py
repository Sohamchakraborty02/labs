# Q15. Write a python program to create a pandas dataframe &amp; then store the content of
# dataframe in a csv file.

import pandas as pd

# Create a DataFrame
data = {
    'Name': ['John', 'Alice', 'Bob'],
    'Age': [25, 30, 22],
}
df = pd.DataFrame(data)
print("Original Datafram")
print(df)

# Store DataFrame content in a CSV file
df.to_csv('output.csv', index=False)

print("DataFrame content has been written to 'output.csv'")

