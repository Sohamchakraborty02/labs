# Q12. Write a python program toconvert second column of the last two rows of a DataFrame as
# a Series.
import pandas as pd


# Function to create a DataFrame from user input
def create_dataframe_from_input():
    n = int(input("Enter the number of rows: "))
    m = int(input("Enter the number of columns: "))
    
    data = {}
    for col in range(m):
        column_name = input(f"Enter the name for column {col + 1}: ")
        data[column_name] = []
        for row in range(n):
            value = input(f"Enter the value for {column_name} in row {row + 1}: ")
            data[column_name].append(value)
    
    return pd.DataFrame(data)

# Create DataFrame from user input
df = create_dataframe_from_input()
print("Original DataFrame:\n", df)

# Check if the DataFrame has at least two rows and two columns
if df.shape[0] < 2 or df.shape[1] < 2:
    print("Error: DataFrame must have at least two rows and two columns.")
else:
    # Extract the second column of the last two rows as a Series
    second_column_name = df.columns[1]
    series = df.iloc[-2:, 1]
    print(f"Second column ({second_column_name}) of the last two rows as a Series:\n", series)


# Input 

# (base) PS C:\Users\Abhishek\music\code> python panda03.py
# Enter the number of rows: 3
# Enter the number of columns: 4
# Enter the name for column 1: col01
# Enter the value for col01 in row 1: 1
# Enter the value for col01 in row 2: 5
# Enter the value for col01 in row 3: 9
# Enter the name for column 2: col02
# Enter the value for col02 in row 1: 2
# Enter the value for col02 in row 2: 6
# Enter the value for col02 in row 3: 10
# Enter the name for column 3: col03
# Enter the value for col03 in row 1: 3
# Enter the value for col03 in row 2: 7
# Enter the value for col03 in row 3: 11
# Enter the name for column 4: col04
# Enter the value for col04 in row 1: 4
# Enter the value for col04 in row 2: 8
# Enter the value for col04 in row 3: 12
# Original DataFrame:
#    col01 col02 col03 col04
# 0     1     2     3     4
# 1     5     6     7     8
# 2     9    10    11    12
# Second column (col02) of the last two rows as a Series:
#  1     6
# 2    10
# Name: col02, dtype: object