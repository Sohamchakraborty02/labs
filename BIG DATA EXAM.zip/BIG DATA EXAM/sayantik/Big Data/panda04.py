# Q13. Write a python program to change the index label of a given series where new index label
# will be given by user then print the (i) series, (ii) print keys and values separetely.

import pandas as pd

# Create a Series with initial index [0, 1, 2, 3]
series = pd.Series([25,26,4,14], index=[0, 1, 2, 3])

# Display the original series
print("Original Series:\n", series)

# Function to get new index labels from user
def get_new_index_labels():
    new_index = []
    for i in range(len(series)):
        new_label = int(input(f"Enter new index label for element {i}: "))
        new_index.append(new_label)
    return new_index

# Get new index labels from user
new_index = get_new_index_labels()
series.index = new_index

# Print the updated series
print("Updated Series:\n", series)

# Print keys and values separately
print("Keys (Index Labels):", list(series.index))
print("Values:", list(series.values))
