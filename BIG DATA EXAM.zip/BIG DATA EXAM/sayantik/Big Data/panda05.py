# Q14. Write a python program to read a CSV file &amp; then i) print all data, ii) print first 3 rows &amp; iii)
# print last 3 rows of 1st column.

import pandas as pd

# Read the CSV file
df = pd.read_csv('1800.csv')

# Print all data
print("All Data:\n", df)

# Print first 3 rows
print("First 3 rows:\n", df.head(3))

# Print last 3 rows of the first column
print("Last 3 rows of the first column:\n", df.iloc[-3:, 0])
