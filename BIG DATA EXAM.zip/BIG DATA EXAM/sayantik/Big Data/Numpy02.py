# Q7. Write a python program to take 3x3 matrix with initial values ,then add a new row (with
# values) and add a new column(with values) in above array using NumPy.

import numpy as np

matrix = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
print("Initial 3x3 Matrix:")
print(matrix)
new_row = list(map(int, input("\nEnter values for the new row (separated by space): ").split()))
new_column = list(map(int, input("Enter values for the new column (separated by space): ").split()))
matrix_with_new_row = np.vstack([matrix, new_row])
matrix_with_new_column = np.column_stack([matrix_with_new_row, new_column])
print("\nMatrix after adding new row and new column:")
print(matrix_with_new_column)

