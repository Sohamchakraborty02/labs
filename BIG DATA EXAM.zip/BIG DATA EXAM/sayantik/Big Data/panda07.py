# Q16. Write a python program to take a CSV file and display then content as dataframe and then
# append/insert new row to that csv file.

import pandas as pd

# Read the CSV file
df = pd.read_csv('1800.csv')
print("Original DataFrame:\n", df)

# Append a new row
new_row = {'name': 'D', 'Age': '22'}
df = df.append(new_row, ignore_index=True)

# Display updated DataFrame
print("DataFrame after appending a new row:\n", df)

# Save the updated DataFrame back to the CSV file
df.to_csv('1800.csv', index=False)

print("New row has been appended and the updated DataFrame has been saved to '1800.csv'")
