# Q11. Write a python program to add, subtract, multiple and divide two Series using pandas.

import pandas as pd

# Function to create a series from user input
def create_series_from_input(prompt):
    print(prompt)
    n = int(input("Enter the number of elements: "))
    elements = []
    for i in range(n):
        element = float(input(f"Enter element {i + 1}: "))
        elements.append(element)
    return pd.Series(elements)

# Create two series from user input
series1 = create_series_from_input("Enter elements for the first series:")
series2 = create_series_from_input("Enter elements for the second series:")

# Ensure both series have the same length
if len(series1) != len(series2):
    print("Error: Both series must have the same number of elements.")
else:
    # Addition
    addition = series1 + series2
    print("Addition:\n", addition)

    # Subtraction
    subtraction = series1 - series2
    print("Subtraction:\n", subtraction)

    # Multiplication
    multiplication = series1 * series2
    print("Multiplication:\n", multiplication)

    # Division
    division = series1 / series2
    print("Division:\n", division)
