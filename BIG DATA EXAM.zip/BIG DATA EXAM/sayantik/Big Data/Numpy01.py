    # Q6. Write a python program to input nXm matrix when row(n) and column(m) are user input
    # then do the following operations using NumPy
    #  Print maximum and minimum element from in the given array .
    #  Sort the whole array
    #  Sort row wise
    #  Sort column wise

import numpy as np

# Input dimensions
n = int(input("Enter the number of rows: "))
m = int(input("Enter the number of columns: "))

# Input matrix elements
matrix = []
print("Enter the elements of the matrix:")
for i in range(n):
    row = list(map(int, input().split()))
    matrix.append(row)

# Convert list to NumPy array
arr = np.array(matrix)

# Print maximum and minimum element
print("Maximum element:", np.max(arr))
print("Minimum element:", np.min(arr))

# Sort the whole array
sorted_arr = np.sort(arr, axis=None)
print("Sorted array:", sorted_arr)

# Sort row-wise
row_sorted_arr = np.sort(arr, axis=1)
print("Row-wise sorted array:\n", row_sorted_arr)

# Sort column-wise
col_sorted_arr = np.sort(arr, axis=0)
print("Column-wise sorted array:\n", col_sorted_arr)
