# Q9. Write a NumPy program to sort a given array of shape 2 along the first axis, last axis and on
# flattened array.

import numpy as np

rows = int(input("Enter the number of rows: "))
cols = int(input("Enter the number of columns: "))

print(f"Enter the elements of the {rows}x{cols} array row by row:")
array = []
for i in range(rows):
    row = list(map(int, input(f"Enter elements of row {i+1} (separated by spaces): ").split()))
    array.append(row)

array = np.array(array)

print("\nOriginal Array:")
print(array)

sorted_first_axis = np.sort(array, axis=0)
print("\nSorted along the first axis (axis=0):")
print(sorted_first_axis)

sorted_last_axis = np.sort(array, axis=-1)
print("\nSorted along the last axis (axis=-1):")
print(sorted_last_axis)

sorted_flattened = np.sort(array.flatten())
print("\nSorted flattened array:")
print(sorted_flattened)
