# Q10. Write a python program to create a user-defined dictionary and thereby to convert it to a
# corresponding series using pandas.

import pandas as pd

# Function to take user input and create a dictionary
def create_user_defined_dict():
    user_dict = {}
    print("Enter the number of key-value pairs you want to add:")
    n = int(input("Number of pairs: "))
    
    for _ in range(n):
        key = input("Enter key: ")
        value = input("Enter value: ")
        user_dict[key] = value
    
    return user_dict

# Create user-defined dictionary
user_dict = create_user_defined_dict()

# Convert dictionary to Pandas Series
series = pd.Series(user_dict)
print("Pandas Series:\n", series)

#Output:
#Number of pairs: 3 
#Enter key: name
#Enter value: pritam
#Enter key: age
#Enter value: 22
#Enter key: occupation
#Enter value: software engineer
#Pandas Series:
# name                     pritam
#age                          22
#occupation    software engineer
#dtype: object
