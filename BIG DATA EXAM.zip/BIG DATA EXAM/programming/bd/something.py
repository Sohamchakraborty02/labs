import pandas as pd

# Read the Titanic dataset from a CSV file
titanic_csv = pd.read_csv("Titanic-Dataset.csv")

# Print the entire DataFrame
print(titanic_csv.to_string())

# Print the first 3 rows of the DataFrame
print(titanic_csv.head(3).to_string())

# Print the last 3 rows of the DataFrame
print(titanic_csv.tail(3).to_string())
