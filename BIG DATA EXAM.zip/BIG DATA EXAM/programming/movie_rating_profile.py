from mrjob.job import MRJob

class MovieRatingProfile(MRJob):

    def mapper(self, _, line):
        # Fields: user_id, item_id, rating, timestamp
        parts = line.strip().split('\t')
        if len(parts) == 4:
            movie_id = parts[1]
            yield movie_id, 1

    def reducer(self, movie_id, counts):
        yield movie_id, sum(counts)

if __name__ == '__main__':
    MovieRatingProfile.run()
