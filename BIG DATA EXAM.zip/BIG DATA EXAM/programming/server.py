import socket

# Step 2: Create a UDP socket
broadcast_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
broadcast_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

# Step 3: Define the broadcast address and port
broadcast_address = ('255.255.255.255', 12345)  # Using a common broadcast address

# Step 4: Enter a loop that continues indefinitely
while True:
    # Step 4a: Prompt the user to enter a message
    message = input("Enter a message to broadcast (or type 'exit' to quit): ")

    # Step 4b: Check if the message is 'exit'
    if message.lower() == 'exit':
        break

    # Step 4c: Encode the message to bytes
    encoded_message = message.encode()

    # Step 4d: Send the message to the broadcast address
    broadcast_socket.sendto(encoded_message, broadcast_address)

# Step 5: Close the server socket
broadcast_socket.close()
