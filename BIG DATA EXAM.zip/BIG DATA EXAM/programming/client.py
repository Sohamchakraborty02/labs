import socket

# Step 2: Create a UDP socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Step 3: Bind the client socket to a specific address and port
client_socket.bind(('0.0.0.0', 12345))

# Step 4: Set the socket option to receive broadcast messages
client_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

# Step 5: Print message indicating client is ready to receive
print("Client is ready to receive broadcast messages...")

# Step 6: Enter a loop that continues indefinitely
while True:
    # Step 6a: Use recvfrom() to receive data and sender's address
    data, sender_address = client_socket.recvfrom(1024)  # 1024 is the buffer size

    # Step 6b: Decode the received data to string
    decoded_message = data.decode()

    # Step 6c: Print the received message and sender's address
    print(f"Received message: '{decoded_message}' from {sender_address}")

# Step 7: After exiting the loop, close the client socket
client_socket.close()
